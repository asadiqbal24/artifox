"use strict";

var simple_map = new GMaps({
  div: '#simple-map',
  lat: 23.031741,
  lng: 72.518850
})
