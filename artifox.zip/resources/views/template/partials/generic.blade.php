@extends('template.partials.default')
@section('content')
<div class="main-content">
  <section class="section">
  </section>
</div>

@endsection()