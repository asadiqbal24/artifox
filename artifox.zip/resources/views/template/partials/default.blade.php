@include('template.partials.head')
@include('template.partials.navbar')
@include('template.partials.sidebar')
@yield('content')
@include('template.partials.settingsidebar')

@include('template.partials.footer')