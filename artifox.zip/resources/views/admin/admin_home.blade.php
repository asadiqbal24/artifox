@extends('template.partials.default')
@section('content')
<div class="main-content">
  <section class="section">
    <h5>Hello Admin</h5>
  </section>
</div>

@endsection()